<?php
$_SESSION['init']['authorization']=1;
?>