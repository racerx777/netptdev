<?php 
require_once($_SERVER['DOCUMENT_ROOT'] . '/common/redirect.php'); 
?>