<?php
require_once($_SERVER['DOCUMENT_ROOT'] . '/common/session.php');
securitylevel(11); 
errorclear();

if(!empty($cpid)) {
	// trim and strip all input
	foreach($_POST as $key=>$val) {
		if($key != 'button') {
			if(is_string($_POST[$key]))
				$_POST[$key] = stripslashes(strip_tags(trim($val)));
		}
	}

	// Validate form fields
	require_once('prescriptionValidation.php');
	
	if(errorcount() == 0) {
		require_once($_SERVER['DOCUMENT_ROOT'] . '/config/mysql/wsptn_db.php');
		$dbhandle = dbconnect();
		
		$set=array();
		//declare the SQL statement that will query the database
		$query = "UPDATE case_prescriptions ";

		if(isset($_POST['cpcrid'])) 
			$set[] = "cpcrid ='" . mysqli_real_escape_string($dbhandle,$_POST['cpcrid']) . "'";
		if(isset($_POST['cpdx1'])) 
			$set[] .= "cpdx1 ='" . mysqli_real_escape_string($dbhandle,$_POST['cpdx1']) . "'";
		if(isset($_POST['cpdx2'])) 
			$set[] .= "cpdx2 ='" . mysqli_real_escape_string($dbhandle,$_POST['cpdx2']) . "'";
		if(isset($_POST['cpdx3'])) 
			$set[] .= "cpdx3 ='" . mysqli_real_escape_string($dbhandle,$_POST['cpdx3']) . "'";
		if(isset($_POST['cpdx4'])) 
			$set[] .= "cpdx4 ='" . mysqli_real_escape_string($dbhandle,$_POST['cpdx4']) . "'";
		if(isset($_POST['cpfrequency'])) 
			$set[] .= "cpfrequency='" . mysqli_real_escape_string($dbhandle,$_POST['cpfrequency']) . "'";
		if(isset($_POST['cpduration'])) 
			$set[] .= "cpduration='" . mysqli_real_escape_string($dbhandle,$_POST['cpduration']) . "'";
		if(!empty($_POST['cptotalvisits'])) 
			$set[] .= "cptotalvisits='" . mysqli_real_escape_string($dbhandle,$_POST['cptotalvisits']) . "'";
		else 
			$set[] .= "cptotalvisits=NULL";
		if(isset($_POST['cpttmcode'])) 
			$set[] .= "cpttmcode='" . mysqli_real_escape_string($dbhandle,$_POST['cpttmcode']) . "'";
		if(isset($_POST['cpdmid'])) 
			$set[] .= "cpdmid='" . mysqli_real_escape_string($dbhandle,$_POST['cpdmid']) . "'";
		if(isset($_POST['cpdlid'])) 
			$set[] .= "cpdlid='" . mysqli_real_escape_string($dbhandle,$_POST['cpdlid']) . "'";
		if(!empty($_POST['cpdate'])) 
			$set[] .= "cpdate='" . mysqli_real_escape_string($dbhandle,dbDate($_POST['cpdate'])) . "'";
		else
			$set[] .= "cpdate=NULL";
		if(!empty($_POST['cpexpiredate'])) 
			$set[] .= "cpexpiredate='" . mysqli_real_escape_string($dbhandle,dbDate($_POST['cpexpiredate'])) . "'";
		else
			$set[] .= "cpexpiredate=NULL";			
		if(isset($_POST['cptherap'])) 
			$set[] .= "cptherap='" . mysqli_real_escape_string($dbhandle,$_POST['cptherap']) . "'";
		if(isset($_POST['cpcnum'])) 
			$set[] .= "cpcnum='" . mysqli_real_escape_string($dbhandle,$_POST['cpcnum']) . "'";
		if(isset($_POST['cpnote'])) 
			$set[] .= "cpnote='" . mysqli_real_escape_string($dbhandle,$_POST['cpnote']) . "'";
		if(count($set) > 0)
			$query .= "SET " . implode(', ', $set);
		$query .= " WHERE cpid='$cpid'";
//dump("query",$query);
		//execute the SQL query 
		$result = mysqli_query($dbhandle,$query);
		if($result) {
			$_SESSION['notify'][] = "Record successfully updated.";
			foreach($_POST as $key=>$val) 
				unset($_POST[$key]);
		}
		else
			error('001', "Error Updating Record : " . mysqli_error($dbhandle)); 	
		//close the connection
		mysqli_close($dbhandle);
	}
}
else 
	error('000', "Error cpid : $cpid");
?>