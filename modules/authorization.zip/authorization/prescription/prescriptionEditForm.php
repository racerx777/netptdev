<?php
require_once($_SERVER['DOCUMENT_ROOT'] . '/common/session.php');
securitylevel(11); 
errorclear();
require_once($_SERVER['DOCUMENT_ROOT'] . '/config/mysql/wsptn_db.php');
$dbhandle = dbconnect();


if(!empty($cpid)) {
	$buttonaction = "Update Prescription";
	if(!isset($_POST['formLoaded'])) {
		$query = "SELECT * FROM case_prescriptions WHERE cpid='" . $cpid . "'";
		if($resultid = mysqli_query($dbhandle,$query)) {
			$numRows = mysqli_num_rows($resultid);
			if($numRows==1) {
				$result = mysqli_fetch_assoc($resultid);
				foreach($result as $key=>$val) {
					$_POST[$key] = $val;
				}
				$buttonid = $cpid;
				$crid = $_POST['cpcrid'];
	// Default NULL values from case
		// Get Previous Prescription Defaults
				$cpquery = "SELECT cpdmid, cpdlid, cpcnum, cpttmcode, cpdx1, cpdx2, cpdx3, cpdx4, cptherap, cpfrequency, cpduration, cptotalvisits from case_prescriptions WHERE cpcrid='$crid' ORDER BY cpdate DESC LIMIT 1";
				if($cpresult = mysqli_query($dbhandle,$cpquery)) {
					if($cprow = mysqli_fetch_assoc($cpresult)) {
						if(empty($_POST['cpdmid']))
							$_POST['cpdmid'] = $cprow['cpdmid'];
						if(empty($_POST['cpdlid']))
							$_POST['cpdlid'] = $cprow['cpdlid'];
						if(empty($_POST['cpcnum']))
							$_POST['cpcnum'] = $cprow['cpcnum'];
						if(empty($_POST['cpttmcode']))
							$_POST['cpttmcode'] = $cprow['cpttmcode'];
						if(empty($_POST['cpdx1']))
							$_POST['cpdx1'] = $cprow['cpdx1'];
						if(empty($_POST['cpdx2']))
							$_POST['cpdx2'] = $cprow['cpdx2'];
						if(empty($_POST['cpdx3']))
							$_POST['cpdx3'] = $cprow['cpdx3'];
						if(empty($_POST['cpdx4']))
							$_POST['cpdx4'] = $cprow['cpdx4'];
						if(empty($_POST['cptherap']))
							$_POST['cptherap'] = $cprow['cptherap'];
						if(empty($_POST['cpfrequency'])) 
							$_POST['cpfrequency'] = $cprow['cpfrequency'];
						if(empty($_POST['cpduration']))
							$_POST['cpduration'] = $cprow['cpduration'];
						if(empty($_POST['cptotalvisits']))
							$_POST['cptotalvisits'] = $cprow['cptotalvisits'];
					}
					else
						error("004", "Fetch error. $cpquery<br>" . mysqli_error($dbhandle));	
				}
				else
					error("003", "Select error. $cpquery<br>" . mysqli_error($dbhandle));	
		// Get Case Information Defaults
				$crquery = "SELECT crdate, crrefdmid, crrefdlid, crcnum, crtherapytypecode FROM cases WHERE crid='$crid' LIMIT 1";
				if($crresult = mysqli_query($dbhandle,$crquery)) {
					if($crrow = mysqli_fetch_assoc($crresult)) {
						if(empty($_POST['cpdate']))
							$_POST['cpdate'] = $crrow['crdate'];
						if(empty($_POST['cpdmid']))
							$_POST['cpdmid'] = $crrow['crrefdmid'];
						if(empty($_POST['cpdlid']))
							$_POST['cpdlid'] = $crrow['crrefdlid'];
						if(empty($_POST['cpcnum']))
							$_POST['cpcnum'] = $crrow['crcnum'];
						if(empty($_POST['cpttmcode']))
							$_POST['cpttmcode'] = $crrow['crtherapytypecode'];
					}
					else
						error("002", "Fetch error. $crquery<br>" . mysqli_error($dbhandle));	
				}
				else
					error("001", "Select error. $crquery<br>" . mysqli_error($dbhandle));	
			}
			else
				error("002", "Non-unique cpid error (should never happen).");	
		}
		else
			error("001", mysqli_error($dbhandle));
	}
}
else {
	if(!empty($crid)) {
		$buttonaction = "Insert Prescription";
		$buttonid=$crid;
		if(!isset($_POST['formLoaded'])) {
	// Get Last/Previous Prescription Defaults for this case
			$cpquery = "SELECT cpdmid, cpdlid, cpcnum, cpttmcode, cpdx1, cpdx2, cpdx3, cpdx4, cptherap, cpfrequency, cpduration, cptotalvisits from case_prescriptions WHERE cpcrid='$crid' ORDER BY cpdate DESC LIMIT 1";
			if($cpresult = mysqli_query($dbhandle,$cpquery)) {
				if($cprow = mysqli_fetch_assoc($cpresult)) {
					if(empty($_POST['cpdmid']))
						$_POST['cpdmid'] = $cprow['cpdmid'];
					if(empty($_POST['cpdlid']))
						$_POST['cpdlid'] = $cprow['cpdlid'];
					if(empty($_POST['cpcnum']))
						$_POST['cpcnum'] = $cprow['cpcnum'];
					if(empty($_POST['cpttmcode']))
						$_POST['cpttmcode'] = $cprow['cpttmcode'];
					if(empty($_POST['cpdx1']))
						$_POST['cpdx1'] = $cprow['cpdx1'];
					if(empty($_POST['cpdx2']))
						$_POST['cpdx2'] = $cprow['cpdx2'];
					if(empty($_POST['cpdx3']))
						$_POST['cpdx3'] = $cprow['cpdx3'];
					if(empty($_POST['cpdx4']))
						$_POST['cpdx4'] = $cprow['cpdx4'];
					if(empty($_POST['cptherap']))
						$_POST['cptherap'] = $cprow['cptherap'];
					if(empty($_POST['cpfrequency']))
						$_POST['cpfrequency'] = $cprow['cpfrequency'];
					if(empty($_POST['cpduration']))
						$_POST['cpduration'] = $cprow['cpduration'];
					if(empty($_POST['cptotalvisits']))
						$_POST['cptotalvisits'] = $cprow['cptotalvisits'];
				}
	// No else, because this is an insert
	//			else
	//				error("014", "Fetch error. $cpquery<br>" . mysqli_error($dbhandle));	
			}
			else
				error("013", "Select error. $cpquery<br>" . mysqli_error($dbhandle));	
	// Get Case Information Defaults
			$crquery = "SELECT crdate, crrefdmid, crrefdlid, crcnum, crtherapytypecode FROM cases WHERE crid='$crid' LIMIT 1";
			if($crresult = mysqli_query($dbhandle,$crquery)) {
				if($crrow = mysqli_fetch_assoc($crresult)) {
					if(empty($_POST['cpdate']))
						$_POST['cpdate'] = $crrow['crdate'];
					if(empty($_POST['cpdmid']))
						$_POST['cpdmid'] = $crrow['crrefdmid'];
					if(empty($_POST['cpdlid']))
						$_POST['cpdlid'] = $crrow['crrefdlid'];
					if(empty($_POST['cpcnum']))
						$_POST['cpcnum'] = $crrow['crcnum'];
					if(empty($_POST['cpttmcode']))
						$_POST['cpttmcode'] = $crrow['crtherapytypecode'];
				}
				else
					error("002", "Fetch error. $crquery<br>" . mysqli_error($dbhandle));	
			}
			else
				error("001", "Select error. $crquery<br>" . mysqli_error($dbhandle));	
		}
	}
	else
		error("000","cpid and crid not set. $crid/$cpid");
}

if(empty($_POST['cpdate']))
	$_POST['cpdate'] = displayDate(date('Y-m-d'));

$icd9codeoptions = "";

if(errorcount() == 0) {
	require_once($_SERVER['DOCUMENT_ROOT'] . '/common/doctor.options.php');
	$doctorlistoptions="";
	$doctorlocationlistoptions="";
	$doctorlocationdisabled='disabled="disabled"';
	$doctorlist  = getDoctorList();
	//dump("doctorlist",$doctorlist);
	if($doctorlist) {
		if(count($doctorlist) > 0) {
			$doctorlistoptions =  getSelectOptions(
				$arrayofarrayitems=$doctorlist, 
				$optionvaluefield='dmid', 
				$arrayofoptionfields=array(
					'dmlname'=>', ', 
					'dmfname'=>'' 
					), 
				$defaultoption=$_POST['cpdmid'], 
				$addblankoption=TRUE, 
				$arraykey='', 
				$arrayofmatchvalues=array()); 
			if(!empty($_POST['cpdmid'])) {
				$doctorlocationdisabled="";
				$doctorlocationlist  = getDoctorLocationList($_POST['cpdmid']);
				$doctorlocationlistoptions = getSelectOptions(
					$arrayofarrayitems=$doctorlocationlist, 
					$optionvaluefield='dlid', 
					$arrayofoptionfields=array(
						'dlname'=>', ', 
						'dlcity'=>', ', 
						'dlphone'=>'' 
						), 
					$defaultoption=$_POST['cpdlid'], 
					$addblankoption=TRUE, 
					$arraykey='', 
					$arrayofmatchvalues=array());
			}
			else
				$doctorlocationlistoptions = '<option value="">Select a Doctor...</option>';
		}
		else
			echo("Error-No Doctors in Doctor Master.");
	}
	else
		echo("Error-getDoctorList.");

	$icd9codearray = icd9CodeOptions();
	$cpdx1html = getSelectOptions($arrayofarrayitems=$icd9codearray, $optionvaluefield='code', $arrayofoptionfields=array('description'=>' (', 'code'=>')'), $defaultoption=$_POST['cpdx1'], $addblankoption=TRUE, $arraykey='', $arrayofmatchvalues=array());
	$cpdx2html = getSelectOptions($arrayofarrayitems=$icd9codearray, $optionvaluefield='code', $arrayofoptionfields=array('description'=>' (', 'code'=>')'), $defaultoption=$_POST['cpdx2'], $addblankoption=TRUE, $arraykey='', $arrayofmatchvalues=array());
	$cpdx3html = getSelectOptions($arrayofarrayitems=$icd9codearray, $optionvaluefield='code', $arrayofoptionfields=array('description'=>' (', 'code'=>')'), $defaultoption=$_POST['cpdx3'], $addblankoption=TRUE, $arraykey='', $arrayofmatchvalues=array());
	$cpdx4html = getSelectOptions($arrayofarrayitems=$icd9codearray, $optionvaluefield='code', $arrayofoptionfields=array('description'=>' (', 'code'=>')'), $defaultoption=$_POST['cpdx4'], $addblankoption=TRUE, $arraykey='', $arrayofmatchvalues=array());
	
	$therapistcodearray = therapistCodeOptions($_POST['cpcnum'], $_POST['cpttmcode']);
	$cptheraphtml = getSelectOptions($arrayofarrayitems=$therapistcodearray, $optionvaluefield='code', $arrayofoptionfields=array('description'=>' (', 'code'=>')'), $defaultoption=$_POST['cptherap'], $addblankoption=FALSE, $arraykey='', $arrayofmatchvalues=array());
?>
<div class="centerFieldset" style="margin-top:100px;">
	<form action="" method="post" name="prescriptionEditForm">
		<fieldset style="text-align:center;">
		<legend><?php echo $buttonaction; ?> Information</legend>
		<table style="text-align:left;">
			<tr>
				<td>Rx Date</td>
				<td nowrap="nowrap" style="text-decoration:none">
					<input id="cpdate" name="cpdate" type="text" size="10" maxlength="10" value="<?php if(isset($_POST['cpdate'])) echo date("m/d/Y", strtotime($_POST['cpdate'])); ?>" onchange="validateDate(this.id)"><img  align="absmiddle" name="anchor1" id="anchor1" src="/img/calendar.gif" onclick="cal.select(document.forms['prescriptionEditForm'].cpdate,'anchor1','MM/dd/yyyy'); return false;" />
				</td>
			</tr>
			<tr>
				<td>Rx Doctor</td>
				<td><select id="cpdmid" name="cpdmid" type="text" size="1" maxlength="30" value="<?php if(isset($_POST['cpdmid'])) echo $_POST['cpdmid'];?>" onchange="javascript:submit()">
<!--				onchange="showDoctorLocations(this.selectedIndex)" />
-->					<?php echo $doctorlistoptions; ?>
					</select></td>
			</tr>
			<tr>
				<td>Rx Doctor Location</td>
				<td><select id="cpdlid" name="cpdlid" type="text" size="1" maxlength="30" value="<?php if(isset($_POST['cpdlid'])) echo $_POST['cpdlid'];?>" <?php echo $doctorlocationdisabled; ?>/>
					<?php echo $doctorlocationlistoptions; ?>
					</select>
				</td>
			</tr>
			<tr>
				<td>Dx1</td>
				<td><select name="cpdx1" id="cpdx1">
						<?php echo $cpdx1html; ?>
					</select>
				</td>
			</tr>
			<tr>
				<td>Dx2</td>
				<td><select name="cpdx2" id="cpdx2">
						<?php echo $cpdx2html; ?>
					</select>
				</td>
			</tr>
			<tr>
				<td>Dx3</td>
				<td><select name="cpdx3" id="cpdx3">
						<?php echo $cpdx3html; ?>
					</select>
				</td>
			</tr>
			<tr>
				<td>Dx4</td>
				<td><select name="cpdx4" id="cpdx4">
						<?php echo $cpdx4html; ?>
					</select>
				</td>
			</tr>
			<tr>
				<td>Therapy Clinic</td>
				<td><select name="cpcnum" id="cpcnum" onchange="javascript:submit()">
						<?php echo getSelectOptions($arrayofarrayitems=$_SESSION['useraccess']['clinics'], $optionvaluefield='cmcnum', $arrayofoptionfields=array('cmname'=>' (', 'cmcnum'=>')'), $defaultoption=$_POST['cpcnum'], $addblankoption=TRUE, $arraykey='', $arrayofmatchvalues=array()); ?>
					</select>
					</td>
			</tr>
			<tr>
				<td>Therapy Type</td>
				<td><select name="cpttmcode" id="cpttmcode" onchange="javascript:submit()">
						<?php echo getSelectOptions($arrayofarrayitems=therapyTypeOptions(), $optionvaluefield='value', $arrayofoptionfields=array('title'=>' (', 'value'=>')'), $defaultoption=$_POST['cpttmcode'], $addblankoption=FALSE, $arraykey='', $arrayofmatchvalues=array()); ?>
					</select>
				</td>
			</tr>
			<tr>
				<td>Therapy Therapist</td>
				<td><select name="cptherap" id="cptherap">
						<?php echo $cptheraphtml; ?>
					</select>
				</td>
			</tr>
			<tr>
				<td>Frequency </td>
				<td><select name="cpfrequency" id="cpfrequency">
					<option value=""<?php if(empty($_POST['cpfrequency'])) echo ' selected="selected"'; ?>></option>
					<option value="1"<?php if($_POST['cpfrequency']=='1') echo ' selected="selected"'; ?>>1</option>
					<option value="2"<?php if($_POST['cpfrequency']=='2') echo ' selected="selected"'; ?>>2</option>
					<option value="3"<?php if($_POST['cpfrequency']=='3') echo ' selected="selected"'; ?>>3</option>
					<option value="4"<?php if($_POST['cpfrequency']=='4') echo ' selected="selected"'; ?>>4</option>
					<option value="5"<?php if($_POST['cpfrequency']=='5') echo ' selected="selected"'; ?>>5</option>
					<option value="6"<?php if($_POST['cpfrequency']=='6') echo ' selected="selected"'; ?>>6</option>
					<option value="7"<?php if($_POST['cpfrequency']=='7') echo ' selected="selected"'; ?>>7</option>
					</select> 
					times a week				</td>
			</tr>
			<tr>
				<td>Duration </td>
				<td><select name="cpduration" id="cpduration">
					<option value=""<?php if(empty($_POST['cpduration'])) echo ' selected="selected"'; ?>></option>
					<option value="1"<?php if($_POST['cpduration']=='1') echo ' selected="selected"'; ?>>1</option>
					<option value="2"<?php if($_POST['cpduration']=='2') echo ' selected="selected"'; ?>>2</option>
					<option value="3"<?php if($_POST['cpduration']=='3') echo ' selected="selected"'; ?>>3</option>
					<option value="4"<?php if($_POST['cpduration']=='4') echo ' selected="selected"'; ?>>4</option>
					<option value="5"<?php if($_POST['cpduration']=='5') echo ' selected="selected"'; ?>>5</option>
					<option value="6"<?php if($_POST['cpduration']=='6') echo ' selected="selected"'; ?>>6</option>
					<option value="7"<?php if($_POST['cpduration']=='7') echo ' selected="selected"'; ?>>7</option>
					<option value="8"<?php if($_POST['cpduration']=='8') echo ' selected="selected"'; ?>>8</option>
					<option value="9"<?php if($_POST['cpduration']=='9') echo ' selected="selected"'; ?>>9</option>
					<option value="10"<?php if($_POST['cpduration']=='10') echo ' selected="selected"'; ?>>10</option>
					<option value="11"<?php if($_POST['cpduration']=='11') echo ' selected="selected"'; ?>>11</option>
					<option value="12"<?php if($_POST['cpduration']=='12') echo ' selected="selected"'; ?>>12</option>
					</select> 
					weeks
				</td>
			</tr>
			<tr>
				<td>Total Visits</td>
				<td><input name="cptotalvisits" type="text" size="20" maxlength="20" value="<?php if(isset($_POST['cptotalvisits'])) echo $_POST['cptotalvisits'];?>" />
				</td>
			</tr>
			<tr>
				<td>Rx End Date</td>
				<td nowrap="nowrap" style="text-decoration:none"><input id="cpexpiredate" name="cpexpiredate" type="text" size="10" maxlength="10" value="<?php if(isset($_POST['cpexpiredate'])) echo date("m/d/Y", strtotime($_POST['cpexpiredate'])); ?>" onchange="validateDate(this.id)">
					<img  align="absmiddle" name="anchor2" id="anchor2" src="/img/calendar.gif" onclick="cal.select(document.forms['prescriptionEditForm'].cpexpiredate,'anchor2','MM/dd/yyyy'); return false;" /></td>
			</tr>
			<tr>
				<td colspan="2"><div>
						<div style="float:left; margin:20px;">
							<input name="button[]" type="submit" value="Cancel" />
						</div>
						<div style="float:left; margin:20px;">
							<input name="button[<?php echo $buttonid; ?>]" type="submit" value="<?php echo $buttonaction; ?>" /><input type="hidden" name="formLoaded" value="1" /><input type="hidden" name="cpid" value="<?php echo $_POST['cpid']; ?>" /><input type="hidden" name="cpcrid" value="<?php echo $_POST['cpcrid']; ?>" />
						</div>
					</div></td>
			</tr>
		</table>
		</fieldset>
	</form>
</div>
<?php
}
?>
