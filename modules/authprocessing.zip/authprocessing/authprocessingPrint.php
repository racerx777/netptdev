<?php include("authprocessingPrintRfa.php"); ?>
<p style="page-break-before: always">
<?php include("authprocessingPrintRfaPDF.php"); ?>
<p style="page-break-before: always">
<!-- <p style="page-break-before: always"> -->
<?php include("authprocessingPrintPos.php"); ?> 
