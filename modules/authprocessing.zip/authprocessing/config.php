<?php
$_SESSION['init']['authprocessing']=1;
?>